import { db, auth, signInAnonymously } from "./firebase.js";
import { ref, get, runTransaction, update } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";
import { CONFIG } from "./config.js";

const nums = [...new Set(
    JSON.parse(localStorage.getItem("rifaSelecionados") || "[]")
)].map(n => String(n).padStart(3, "0")).filter(n => /^\d{3}$/.test(n) && Number(n) <= 999);

const numsEl = document.getElementById("nums");
const nomeEl = document.getElementById("nome");
const foneEl = document.getElementById("fone");
const btn = document.getElementById("confirmar");
const msg = document.getElementById("msg");

numsEl.textContent = nums.length
    ? `${nums.join(", ")} • R$ ${(nums.length * CONFIG.valor).toFixed(2).replace(".", ",")}`
    : "Nenhum número selecionado.";

function mostrarMensagem(texto, erro = false) {
    msg.textContent = texto;
    msg.style.color = erro ? "#ff9b9b" : "#b9ff80";
}

function gerarIdReserva() {
    if (crypto.randomUUID) return crypto.randomUUID();
    return `res-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function normalizarTelefone(valor) {
    return valor.replace(/\D/g, "");
}

async function garantirAutenticacao() {
    if (auth.currentUser) return auth.currentUser;
    const credencial = await signInAnonymously(auth);
    return credencial.user;
}

async function liberarNumero(numero, uid) {
    const numeroRef = ref(db, `rifa/numeros/${numero}`);
    await runTransaction(numeroRef, atual => {
        if (!atual) return;
        if (atual.participanteId !== uid) return;
        if (atual.status !== "reservado") return;
        return {
            ...atual,
            status: "disponivel",
            nome: "",
            telefone: "",
            pagamento: false,
            participanteId: "",
            reservaId: "",
            criadoEm: "",
            expiraEm: ""
        };
    });
}

async function reservar() {
    const nome = nomeEl.value.trim();
    const telefone = normalizarTelefone(foneEl.value);

    if (!nome || telefone.length < 10 || !nums.length) {
        mostrarMensagem("Preencha seu nome, um WhatsApp válido e selecione pelo menos um número.", true);
        return;
    }

    btn.disabled = true;
    btn.textContent = "RESERVANDO...";
    mostrarMensagem("Aguarde. Estamos verificando os números...", false);

    const adquiridos = [];
    let uid = null;

    try {
        const user = await garantirAutenticacao();
        uid = user.uid;

        const agora = Date.now();
        const expiraEm = agora + (30 * 60 * 1000);
        const reservaId = gerarIdReserva();

        // Primeiro reservamos cada número de forma transacional.
        // O Firebase só aceita se o número estiver disponível ou expirado.
        for (const numero of nums) {
            const numeroRef = ref(db, `rifa/numeros/${numero}`);

            const resultado = await runTransaction(numeroRef, atual => {
                const expirado = atual?.status === "reservado" && Number(atual.expiraEm || 0) <= Date.now();

                if (!atual) return;

                if (atual.status === "disponivel" || expirado) {
                    return {
                        ...atual,
                        numero,
                        status: "reservado",
                        nome,
                        telefone,
                        pagamento: false,
                        pagamentoStatus: "aguardando_comprovante",
                        participanteId: uid,
                        reservaId,
                        criadoEm: agora,
                        expiraEm,
                        comprovanteEnviado: false,
                        raspadinhaLiberada: false
                    };
                }

                return;
            });

            if (!resultado.committed) {
                throw new Error(`O número ${numero} acabou de ser reservado por outra pessoa.`);
            }

            adquiridos.push(numero);
        }

        // Somente depois de todos os números serem adquiridos criamos a
        // participação. Se esta gravação falhar, o bloco catch devolve os números.
        const reservaRef = ref(db, `rifa/reservas/${reservaId}`);
        await update(reservaRef, {
            reservaId,
            participanteId: uid,
            nome,
            telefone,
            numeros: adquiridos,
            quantidade: adquiridos.length,
            valorUnitario: CONFIG.valor,
            valorTotal: adquiridos.length * CONFIG.valor,
            status: "reservado",
            pagamentoStatus: "aguardando_comprovante",
            pagamento: false,
            comprovanteEnviado: false,
            raspadinhaLiberada: false,
            criadoEm: agora,
            expiraEm
        });

        localStorage.setItem("rifaReservaId", reservaId);
        localStorage.setItem("rifaParticipanteId", uid);
        localStorage.setItem("rifaSelecionados", JSON.stringify(adquiridos));

        mostrarMensagem("Reserva realizada com sucesso! Seus números estão reservados por 30 minutos.");

        const texto = [
            "Olá! Fiz uma reserva na Rifa Entre Amigos.",
            `Nome: ${nome}`,
            `WhatsApp: ${telefone}`,
            `Números: ${adquiridos.join(", ")}`,
            `Total: R$ ${(adquiridos.length * CONFIG.valor).toFixed(2).replace(".", ",")}`,
            `Reserva: ${reservaId}`,
            "Vou enviar o comprovante do pagamento."
        ].join("\n");

        setTimeout(() => {
            window.open(`https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(texto)}`, "_blank");
        }, 250);

    } catch (erro) {
        console.error("Erro ao reservar:", erro);

        // Se algum número já foi adquirido e outro falhou, devolvemos somente
        // os números que pertencem a este participante.
        if (uid && adquiridos.length) {
            await Promise.allSettled(adquiridos.map(numero => liberarNumero(numero, uid)));
        }

        const codigo = erro?.code || "";
        let mensagem = erro?.message || "Não foi possível concluir a reserva.";

        if (codigo === "PERMISSION_DENIED") {
            mensagem = "O Firebase recusou a reserva. Verifique se o login anônimo está ativado no Firebase e publique as regras da Fase 1.1.";
        }

        if (codigo === "auth/operation-not-allowed") {
            mensagem = "O login anônimo ainda não está ativado no Firebase Authentication.";
        }

        mostrarMensagem(mensagem, true);
    } finally {
        btn.disabled = false;
        btn.textContent = "CONFIRMAR RESERVA";
    }
}

btn.addEventListener("click", reservar);

if (!nums.length) {
    btn.disabled = true;
    mostrarMensagem("Volte para a cartela e escolha pelo menos um número.", true);
}
